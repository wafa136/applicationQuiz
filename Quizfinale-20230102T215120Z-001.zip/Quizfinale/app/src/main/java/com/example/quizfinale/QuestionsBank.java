package com.example.quizfinale;

import java.util.ArrayList;
import java.util.List;

public class QuestionsBank {
    static List<QuestionsList>javaQuestions (){
        List<QuestionsList> questionsLists=new ArrayList<>();
        QuestionsList question1=new QuestionsList("what is the size of int variable","16 Bit","8 Bit","32 Bit","64 Bit","32 Bit","");
        QuestionsList question2=new QuestionsList("what is the default value of Boolean variable","true","false","null","not defined","false","");
        QuestionsList question3=new QuestionsList("what of the following  is the default value of in instance variable","depends up on the type of variable","null","0","not assigned","what of the following  is the default value of in instance variable","");

        questionsLists.add(question1);
        questionsLists.add(question2);
        questionsLists.add(question3);
        return questionsLists ;
    }
    static List<QuestionsList>phpQuestions (){
        List<QuestionsList> questionsLists=new ArrayList<>();
        QuestionsList question1=new QuestionsList("what does PHP stand for","professional home page ","hypertext preprocessor","pretext hypertext preprocessor ","preprocessor home page","hypertext preprocessor","");
        QuestionsList question2=new QuestionsList("who is the father of php","Rasmus lerdorf","willam makepiece","drek kolkevi","list barely","Rasmus lerdorf","");
        QuestionsList question3=new QuestionsList("php files have a default file extension of  ",".html",".php",".xml",".json",".php","");

        questionsLists.add(question1);
        questionsLists.add(question2);
        questionsLists.add(question3);
        return questionsLists ;
}
    static List<QuestionsList>histoireQuestions (){
        List<QuestionsList> questionsLists=new ArrayList<>();
        QuestionsList question1=new QuestionsList("Connu sous le surnom “Le Roi-Soleil” quel autre surnom était attribué à Louis XIV ?is XIV ?","le génie "," le beau","le vaillant ","le grand "," le grand","");
        QuestionsList question2=new QuestionsList("Quelle est l’année de naissance de Louis XIV ?","1628","1638 ","1648","1658","1638 ","");
        QuestionsList question3=new QuestionsList("Quel est l’âge de Louis XIV quand il devient roi ? ","1 ans et 5 mois"," 4 ans et 8 mois","7 ans et 3 mois","9 ans et 11 mois","4 ans et 8 mois","");

        questionsLists.add(question1);
        questionsLists.add(question2);
        questionsLists.add(question3);
        return questionsLists ;
    }
    static List<QuestionsList>geographieQuestions (){
        List<QuestionsList> questionsLists=new ArrayList<>();
        QuestionsList question1=new QuestionsList("Quel est le plus haut sommet du monde ?","kilimandjaro","everest","mont fuji","mont blanc","everest","");
        QuestionsList question2=new QuestionsList("Quelle est la hauteur à la pointe de l’Everest ?","7549m","8249m","8849m","9349m","8849m","");
        QuestionsList question3=new QuestionsList("Quel est le second sommet le plus haut du monde après l’Everest ?","Annapurna","Makalu","K2","aconcagua","K2","");

        questionsLists.add(question1);
        questionsLists.add(question2);
        questionsLists.add(question3);
        return questionsLists ;
    }
    public static List<QuestionsList>getQuestions(String selectedTopicName){

        switch (selectedTopicName){
            case "java":
                return javaQuestions();
            case "php":
                    return phpQuestions();
            case "histoire":
                return histoireQuestions();
            default:
                return geographieQuestions();

        }
}


}
