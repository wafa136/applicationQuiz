package com.example.quizfinale;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class QuizActivity extends AppCompatActivity {
TextView questions;
TextView question ;
AppCompatButton option1,option2,option3,option4,nextbtn;
ImageView btnback ;
List<QuestionsList> questionsLists;
int currentQuestinPosition=0;
String selectedOptionByUser= "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        String getselectedTopicName= getIntent().getStringExtra("selecttopic");
        ImageView btnback=findViewById(R.id.btnback);
        TextView selectedtopicname =findViewById(R.id.text4);
        selectedtopicname.setText(getselectedTopicName);
        questions=findViewById(R.id.questions);
        question=findViewById(R.id.question);
        option1=findViewById(R.id.option1);
        option2=findViewById(R.id.option2);
        option3=findViewById(R.id.option3);
        option4=findViewById(R.id.option4);
        questionsLists=QuestionsBank.getQuestions(getselectedTopicName);

        questions.setText((currentQuestinPosition+1)+"/"+questionsLists.size());
        question.setText(questionsLists.get(0).getQuestion());
        option1.setText(questionsLists.get(0).getOption1());
        option2.setText(questionsLists.get(0).getOption2());
        option3.setText(questionsLists.get(0).getOption3());
        option4.setText(questionsLists.get(0).getOption4());

    btnback.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent=new Intent(QuizActivity.this,MainActivity2.class);
            startActivity(intent);
        }
    });


        nextbtn=findViewById(R.id.nextbtn);

      option1.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
                     if (selectedOptionByUser.isEmpty()){
                         selectedOptionByUser=option1.getText().toString();
                         option1.setBackgroundResource(R.drawable.roundred);
                      revealAnswer();
                      questionsLists.get(currentQuestinPosition).setUserSelectedAnswer(selectedOptionByUser);
                     }
          }
      });
      option2.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              if (selectedOptionByUser.isEmpty()){
                  selectedOptionByUser=option2.getText().toString();
                  option2.setBackgroundResource(R.drawable.roundred);
                  revealAnswer();
                  questionsLists.get(currentQuestinPosition).setUserSelectedAnswer(selectedOptionByUser);
              }
          }
      });
      option3.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              if (selectedOptionByUser.isEmpty()){
                  selectedOptionByUser=option3.getText().toString();
                  option3.setBackgroundResource(R.drawable.roundred);
                  revealAnswer();
                  questionsLists.get(currentQuestinPosition).setUserSelectedAnswer(selectedOptionByUser);
              }
          }
      });
      option4.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              if (selectedOptionByUser.isEmpty()){
                  selectedOptionByUser=option4.getText().toString();
                  option4.setBackgroundResource(R.drawable.roundred);
                  revealAnswer();
                  questionsLists.get(currentQuestinPosition).setUserSelectedAnswer(selectedOptionByUser);
              }
          }
      });
      nextbtn.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
                if (selectedOptionByUser.isEmpty()){
                    Toast.makeText(QuizActivity.this, "please select an option", Toast.LENGTH_SHORT).show();
                } else{
                    changeNextQuestion ();
                }
          }
      });

    }

    private int getCorrectAnswers (){
        int correctAnswers=0;
        for (int i=0;i<questionsLists.size();i++){
            String getUserSelectedAnswers=questionsLists.get(i).getUserSelectedAnswer();
            String getAnswer=questionsLists.get(i).getAnswer();
            if (getUserSelectedAnswers.equals(getAnswer)){
                correctAnswers ++;
            }
        }
        return correctAnswers;
    }

    private int getinCorrectAnswers (){
        int correctAnswers=0;
        for (int i=0;i<questionsLists.size();i++){
            String getUserSelectedAnswers=questionsLists.get(i).getUserSelectedAnswer();
            String getAnswer=questionsLists.get(i).getAnswer();
            if (!getUserSelectedAnswers.equals(getAnswer)){
                correctAnswers ++;
            }
        }
        return correctAnswers;
    }
void revealAnswer (){
        String getAnswer=questionsLists.get(currentQuestinPosition).getAnswer();
        if (option1.getText().toString().equals(getAnswer)){
            option1.setBackgroundResource(R.drawable.roundgreen);

        } else if (option2.getText().toString().equals(getAnswer)){
            option2.setBackgroundResource(R.drawable.roundgreen);

        }else if (option3.getText().toString().equals(getAnswer)){
            option3.setBackgroundResource(R.drawable.roundgreen);

        }else if (option4.getText().toString().equals(getAnswer)){
            option4.setBackgroundResource(R.drawable.roundgreen);

        }



}
    private void changeNextQuestion(){
        currentQuestinPosition++;

        if((currentQuestinPosition+1) == questionsLists.size()){
            nextbtn.setText("Submit Quiz");
        }
        if (currentQuestinPosition<questionsLists.size()){
            selectedOptionByUser = "";
            option1.setBackgroundResource (R.drawable.round_white);
            option2.setBackgroundResource (R.drawable.round_white);
            option3.setBackgroundResource (R.drawable.round_white);
            option4.setBackgroundResource (R.drawable.round_white);
            questions.setText((currentQuestinPosition+1)+"/"+questionsLists.size());
            question.setText(questionsLists.get(currentQuestinPosition).getQuestion());
            option1.setText(questionsLists.get(currentQuestinPosition).getOption1());
            option2.setText(questionsLists.get(currentQuestinPosition).getOption2());
            option3.setText(questionsLists.get(currentQuestinPosition).getOption3());
            option4.setText(questionsLists.get(currentQuestinPosition).getOption4());

}

    else {
    Intent in=new Intent(QuizActivity.this,QuizResults.class);
    in.putExtra("correct",getCorrectAnswers());
    in.putExtra("incorrect",getinCorrectAnswers());
    startActivity(in);
    finish();
    }



    }}