package com.example.quizfinale;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
private String selectedTopicName = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        final LinearLayout java = findViewById(R.id.java);
        final LinearLayout php = findViewById(R.id.php);
        final LinearLayout geographie = findViewById(R.id.geographie);
        final LinearLayout histoire = findViewById(R.id.histoire);
        final Button btn3 =findViewById(R.id.btn3);

        java.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 selectedTopicName = "java";
                 java.setBackgroundResource(R.drawable.roundbackff);
                php.setBackgroundResource(R.drawable.round_white);
                geographie.setBackgroundResource(R.drawable.round_white);
                histoire.setBackgroundResource(R.drawable.round_white);
            }
        });

php.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        selectedTopicName = "php";
        php.setBackgroundResource(R.drawable.roundbackff);
        java.setBackgroundResource(R.drawable.round_white);
        geographie.setBackgroundResource(R.drawable.round_white);
        histoire.setBackgroundResource(R.drawable.round_white);

    }
});

histoire.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        selectedTopicName = "histoire";
        histoire.setBackgroundResource(R.drawable.roundbackff);
        java.setBackgroundResource(R.drawable.round_white);
        php.setBackgroundResource(R.drawable.round_white);
        geographie.setBackgroundResource(R.drawable.round_white);
    }
});
geographie.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        selectedTopicName = "geographie";
        geographie.setBackgroundResource(R.drawable.roundbackff);
        java.setBackgroundResource(R.drawable.round_white);
        php.setBackgroundResource(R.drawable.round_white);
        histoire.setBackgroundResource(R.drawable.round_white);
    }
});

btn3.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if (selectedTopicName.isEmpty()){
            Toast.makeText(MainActivity2.this,"please select the topic",Toast.LENGTH_SHORT).show();
        } else {
            Intent i=new Intent(MainActivity2.this,QuizActivity.class);
            i.putExtra("selecttopic",selectedTopicName);
            startActivity(i);
        }
    }
});
    }
}