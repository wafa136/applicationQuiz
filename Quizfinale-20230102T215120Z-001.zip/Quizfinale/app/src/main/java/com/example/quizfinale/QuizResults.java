package com.example.quizfinale;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class QuizResults extends AppCompatActivity {

    AppCompatButton startNewBtn,partage;
    TextView correctAnswer,incorrectAnswers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_results);
        AppCompatButton  startNewBtn =findViewById(R.id.startNewQuizBtn);

        TextView correctAnswer = findViewById(R.id.correctAnswers);
        TextView incorrectAnswers = findViewById(R.id.incorrectAnswers);
        AppCompatButton  partage =findViewById(R.id.partage);

        int getCorrectAnswers = getIntent().getIntExtra("correct",0);
        int getIncorrectAnswers = getIntent().getIntExtra( "incorrect",  0);

        correctAnswer.setText(String.valueOf(getCorrectAnswers));
        incorrectAnswers.setText(String.valueOf(getIncorrectAnswers));

        partage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txt=String.valueOf((getCorrectAnswers)&(getIncorrectAnswers));
                Intent i = new Intent(Intent.ACTION_SEND);
                i.putExtra(i.EXTRA_TEXT,txt);
                i.setType("text/plain");
                Intent chooser = Intent.createChooser(i, "Partage avec");
                startActivity(chooser);
            }
        });

        startNewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity (new Intent(QuizResults.this, MainActivity.class));
                finish();
            }
        });


    }
}